
declare let __IN_DEBUG__: boolean;
declare let __VERSION__: string;
declare let __ASSETS__: {
  [string]: string;
};
